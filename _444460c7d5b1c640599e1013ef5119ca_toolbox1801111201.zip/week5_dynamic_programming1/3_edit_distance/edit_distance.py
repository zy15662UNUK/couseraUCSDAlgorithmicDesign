# Uses python3
def edit_distance(s, t):
    #write your code here
    return 0

if __name__ == "__main__":
    print(edit_distance(input(), input()))
